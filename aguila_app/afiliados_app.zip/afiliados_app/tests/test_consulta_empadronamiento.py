from pathlib import Path
from unittest.mock import patch

from django.contrib.auth.models import Group, User
from django.conf import settings
from django.db import DatabaseError
from django.db.models import Q
from django.test import TestCase
from django.urls import reverse

from afiliados_app.models import PadronElectoral
from afiliados_app.views import GRUPOS_CONSULTA_PADRON, _resultado_padron_local


class ConsultaEmpadronamientoTests(TestCase):
    dpi_existente = '2850755860203'
    dpi_guardado = '2850 75586 0203'

    @classmethod
    def setUpTestData(cls):
        cls.groups = {
            name: Group.objects.create(name=name)
            for name in GRUPOS_CONSULTA_PADRON
        }
        cls.user = User.objects.create_user(username='secretaria', password='test-pass')
        cls.user.groups.add(cls.groups['Organizacion'])
        cls.unauthorized_user = User.objects.create_user(
            username='sin-secretaria', password='test-pass'
        )
        cls.person = PadronElectoral.objects.create(
            identificacion=cls.dpi_guardado,
            nombre='RODAS HERNANDEZ, JULIO RENE',
            edad=40,
            comunidad='PUEBLO SAN AGUSTIN ACASAGUASTLAN',
            departamento='EL PROGRESO',
            municipio='SAN AGUSTÍN ACASAGUASTLÁN',
        )

    def setUp(self):
        self.page_url = reverse('afiliados:consulta_empadronamiento')
        self.api_url = reverse('afiliados:consulta_empadronamiento_api')
        self.verification_url = reverse('afiliados:verificar_empadronamiento')

    def test_anonymous_user_is_redirected_from_page_and_api(self):
        self.assertEqual(self.client.get(self.page_url).status_code, 302)
        self.assertEqual(self.client.get(self.api_url, {'dpi': self.dpi_existente}).status_code, 302)

    def test_user_without_authorized_group_is_forbidden(self):
        self.client.force_login(self.unauthorized_user)
        self.assertEqual(self.client.get(self.page_url).status_code, 403)
        response = self.client.get(self.api_url, {'dpi': self.dpi_existente})
        self.assertEqual(response.status_code, 403)
        self.assertFalse(response.json()['ok'])

    def test_every_authorized_group_can_open_page_and_query(self):
        for group_name, group in self.groups.items():
            with self.subTest(group=group_name):
                user = User.objects.create_user(username='user-' + group_name)
                user.groups.add(group)
                self.client.force_login(user)
                self.assertEqual(self.client.get(self.page_url).status_code, 200)
                self.assertEqual(
                    self.client.get(self.api_url, {'dpi': self.dpi_existente}).status_code,
                    200,
                )
                self.client.logout()

    def test_gestor_can_use_verification_endpoint(self):
        gestor = User.objects.create_user(username='gestor-padron')
        gestor.groups.add(self.groups['Gestor'])
        self.client.force_login(gestor)

        response = self.client.get(self.verification_url, {'dpi': self.dpi_existente})

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['found'])

    def test_verification_frontend_uses_server_permission_message_and_restores_button(self):
        script_path = (
            Path(__file__).resolve().parents[2]
            / 'static/js/verificar_empadronamiento.js'
        )
        script = script_path.read_text(encoding='utf-8')

        self.assertIn("parseado.error || parseado.message || parseado.mensaje", script)
        self.assertNotIn('CSRF o permiso denegado', script)
        self.assertIn('finally {', script)
        self.assertIn('btn.disabled = false;', script)
        self.assertIn('btn.textContent = originalText;', script)

    def test_page_links_to_configured_tse_site_in_new_tab(self):
        self.client.force_login(self.user)
        response = self.client.get(self.page_url)
        self.assertContains(response, 'href="{}"'.format(settings.TSE_CONSULTA_URL))
        self.assertContains(response, 'target="_blank"')
        self.assertContains(response, 'rel="noopener noreferrer"')

    def test_existing_dpi_returns_only_local_person_data(self):
        self.client.force_login(self.user)
        response = self.client.get(self.api_url, {'dpi': self.dpi_existente})
        payload = response.json()
        self.assertEqual(response.status_code, 200)
        self.assertTrue(payload['found'])
        self.assertEqual(payload['data']['nombre_completo'], self.person.nombre)
        self.assertEqual(payload['data']['municipio'], self.person.municipio)

    def test_missing_dpi_returns_informative_not_found(self):
        self.client.force_login(self.user)
        response = self.client.get(self.api_url, {'dpi': '9999999999999'})
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json()['found'])
        self.assertEqual(response.json()['message'], 'No encontrado en el padrón local.')

    def test_spaces_and_hyphens_are_normalized(self):
        self.client.force_login(self.user)
        for formatted_dpi in (
            self.dpi_existente,
            self.dpi_guardado,
            '2850-75586-0203',
            '2850 75586-0203',
        ):
            with self.subTest(dpi=formatted_dpi):
                response = self.client.get(self.api_url, {'dpi': formatted_dpi})
                self.assertEqual(response.status_code, 200)
                self.assertTrue(response.json()['found'])

    def test_central_lookup_accepts_a_numeric_dpi(self):
        payload, status_code = _resultado_padron_local(int(self.dpi_existente))
        self.assertEqual(status_code, 200)
        self.assertTrue(payload['encontrado'])
        self.assertEqual(payload['dpi'], self.dpi_existente)

    def test_central_lookup_uses_identificacion_field(self):
        with patch(
            'afiliados_app.views.PadronElectoral.objects.filter',
            wraps=PadronElectoral.objects.filter,
        ) as filter_mock:
            payload, status_code = _resultado_padron_local(self.dpi_existente)
        self.assertEqual(status_code, 200)
        self.assertTrue(payload['found'])
        filter_mock.assert_called_once_with(
            Q(identificacion=self.dpi_guardado) |
            Q(identificacion=self.dpi_existente)
        )

    def test_incomplete_or_alphabetic_dpi_is_rejected(self):
        self.client.force_login(self.user)
        for invalid_dpi in ('123456789012', 'A2850755860203', '', None):
            with self.subTest(dpi=invalid_dpi):
                response = self.client.get(self.api_url, {'dpi': invalid_dpi})
                self.assertEqual(response.status_code, 400)
                self.assertFalse(response.json()['ok'])

    def test_database_failure_returns_controlled_error(self):
        self.client.force_login(self.user)
        with patch(
            'afiliados_app.views.PadronElectoral.objects.filter',
            side_effect=DatabaseError('sensitive database detail'),
        ):
            response = self.client.get(self.api_url, {'dpi': self.dpi_existente})
        self.assertEqual(response.status_code, 503)
        self.assertNotContains(response, 'sensitive database detail', status_code=503)

    def test_queries_do_not_create_or_modify_records(self):
        self.client.force_login(self.user)
        before = list(PadronElectoral.objects.values())
        self.client.get(self.api_url, {'dpi': self.dpi_existente})
        self.client.get(self.api_url, {'dpi': '9999999999999'})
        self.client.get(self.api_url, {'dpi': '123'})
        self.assertEqual(list(PadronElectoral.objects.values()), before)
