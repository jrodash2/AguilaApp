from django import forms
from django.contrib.auth.models import User, Group
from django.forms import CheckboxInput, DateInput, inlineformset_factory, modelformset_factory
from django.core.exceptions import ValidationError
import re


from .models import  Perfil,  Institucion, Afiliado, Comunidad, CentroVotacion, Comision, Sector, OrganizacionIntegrante, CoordinadorOrganizacion, LiderComunitarioOrganizacion, EstructuraOrganizativa, ResponsableTerritorial, ReunionTerritorial, IncidenciaTerritorial, JuventudIntegrante, CoordinadorJuventud, LiderJuvenil, EstructuraJuventud, ResponsableJuventud, ReunionJuventud, IncidenciaJuventud, MujeresIntegrante, CoordinadoraMujeres, LiderMujeres, EstructuraMujeres, ResponsableMujeres, ReunionMujeres, IncidenciaMujeres, LogisticaIntegrante, CoordinadorLogistica, LiderLogistica, EstructuraLogistica, ResponsableLogistica, ReunionLogistica, IncidenciaLogistica, RecursoLogistico, AsignacionLogistica, SolicitudLogistica, EntregaLogistica, AgendaLogistica, ComunicacionIntegrante, CoordinadorComunicacion, LiderComunicacion, EstructuraComunicacion, ResponsableComunicacion, ReunionComunicacion, IncidenciaComunicacion, AgendaPublicacion, SolicitudContenido, CoberturaActividad, BancoMedios, CampanaComunicacion, MonitoreoRed, PlanHormigaIntegrante, CoordinadorPlanHormiga, EnlaceTerritorialPlanHormiga, EstructuraPlanHormiga, ResponsableZonaPlanHormiga, ReunionPlanHormiga, IncidenciaPlanHormiga, VisitaPlanHormiga, SeguimientoContactoPlanHormiga, CompromisoTerritorialPlanHormiga, PuntoVisitadoPlanHormiga, ActivacionTerritorialPlanHormiga, CoberturaVisitaPlanHormiga

from django.db.models import Sum, F, Value
from django.db.models.functions import Coalesce



from django import forms
from .models import Institucion

from django.core.exceptions import ValidationError

class InstitucionForm(forms.ModelForm):
    pagina_web = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        help_text='Ingrese URL que comience con www., sin http/https.'
    )

    class Meta:
        model = Institucion
        fields = ['nombre', 'direccion', 'telefono', 'pagina_web', 'logo', 'logo2']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            # 'pagina_web': forms.URLInput(attrs={'class': 'form-control'}),  # quitamos este
            'logo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'logo2': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }

    def clean_pagina_web(self):
        url = self.cleaned_data.get('pagina_web')
        if url:
            if not url.startswith('www.'):
                raise ValidationError('La URL debe comenzar con "www."')
            # Añadimos http:// para que sea una URL válida
            url = 'http://' + url
        return url



from django import forms
from django.contrib.auth.models import User, Group
from .models import Perfil

class UserCreateForm(forms.ModelForm):
    new_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True,
        label="Contraseña"
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        required=True,
        label="Confirmar Contraseña"
    )
    group = forms.ModelChoiceField(
        queryset=Group.objects.all(),
        required=True,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    foto = forms.ImageField(
        required=False,
        widget=forms.ClearableFileInput(attrs={'class': 'form-control'})
    )
    cargo = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('new_password')
        confirm = cleaned_data.get('confirm_password')

        if password != confirm:
            raise forms.ValidationError("Las contraseñas no coinciden.")
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        password = self.cleaned_data.get('new_password')
        user.set_password(password)

        if commit:
            user.save()
            # Asignar grupo
            group = self.cleaned_data.get('group')
            if group:
                user.groups.set([group])

            # Crear perfil
            cargo = self.cleaned_data.get('cargo')
            foto = self.cleaned_data.get('foto')
            Perfil.objects.update_or_create(
                user=user,
                defaults={'cargo': cargo, 'foto': foto}
            )

        return user

class UserEditForm(forms.ModelForm):
    group = forms.ModelChoiceField(
        queryset=Group.objects.all(),
        required=False,
        label="Grupo",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    cargo = forms.CharField(
        max_length=100,
        required=False,
        label="Cargo",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    foto = forms.ImageField(
        required=False,
        label="Foto de perfil",
        widget=forms.ClearableFileInput(attrs={'class': 'form-control'})
    )

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['username'].required = False

        # Cargar valores iniciales del perfil (cargo y foto)
        if self.instance and self.instance.pk:
            perfil = getattr(self.instance, 'perfil', None)
            if perfil:
                self.fields['cargo'].initial = perfil.cargo
                self.fields['foto'].initial = perfil.foto

            groups = self.instance.groups.all()
            if groups.exists():
                self.fields['group'].initial = groups.first()

    def save(self, commit=True):
        user = super().save(commit=commit)

        if commit:
            # Actualizar grupo
            group = self.cleaned_data.get('group')
            if group:
                user.groups.set([group])
            else:
                user.groups.clear()

            # Actualizar perfil
            perfil, created = Perfil.objects.get_or_create(user=user)
            perfil.cargo = self.cleaned_data.get('cargo')
            foto = self.cleaned_data.get('foto')

            if foto:
                perfil.foto = foto

            perfil.save()

        return user


        
class PerfilForm(forms.ModelForm):
    class Meta:
        model = Perfil
        fields = ['foto']
        widgets = {
            'foto': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }


from django import forms
# Asegúrate de importar tu modelo Afiliado
# from .models import Afiliado # o la ruta correcta
# -------------------------------
# Formulario Afiliado
# -------------------------------
class AfiliadoForm(forms.ModelForm):
    comision = forms.ModelChoiceField(
        queryset=Comision.objects.all().order_by('nombre'),
        required=False,
        label='Comisión',
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    cargo_en_comision = forms.ChoiceField(
        choices=[('', '---------')] + list(Afiliado.CargoComision.choices),
        required=False,
        label='Cargo en Comisión',
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    class Meta:
        model = Afiliado
        # ⚠️ IMPORTANTE: Ajustar la lista de campos
        fields = [
            'nombre_completo', 'dpi', 'fecha_nacimiento', 'telefono', 
            'direccion', 'comunidad', 
            'es_lider_comunitario',  # 🌟 NUEVO: El check para ser líder
            'lider_vinculado',       # 🔗 RENOMBRADO: Apunta a otro Afiliado (Líder)
            'empadronado',
            'foto',
        ]
        
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'fecha_nacimiento': forms.DateInput(
                attrs={'class': 'form-control', 'type': 'date'},
                format='%Y-%m-%d'
            ),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'direccion': forms.TextInput(attrs={'class': 'form-control', 'rows': 3}),
            'comunidad': forms.Select(attrs={'class': 'form-control'}),
            'lider_vinculado': forms.Select(attrs={'class': 'form-control'}), # 🔗 RENOMBRADO

            'empadronado': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'es_lider_comunitario': forms.CheckboxInput(attrs={'class': 'form-check-input'}), # 🌟 NUEVO
            'foto': forms.FileInput(attrs={
                'class': 'd-none foto-persona-input',
                'accept': 'image/jpeg,image/png,image/webp',
            }),

        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # ✅ Forzar formato correcto de fecha al cargar el formulario (modo edición)
        if self.instance and self.instance.fecha_nacimiento:
            self.initial['fecha_nacimiento'] = self.instance.fecha_nacimiento.strftime('%Y-%m-%d')

        if self.instance and self.instance.pk:
            self.fields['comision'].initial = self.instance.comisiones.first()
            self.fields['cargo_en_comision'].initial = self.instance.cargo_en_comision
        
        # 🎨 Opcional: Renombrar la etiqueta del campo 'lider_vinculado'
        self.fields['lider_vinculado'].label = 'Líder (Afiliado Referente)'

    def clean(self):
        cleaned_data = super().clean()
        comision = cleaned_data.get('comision')
        cargo = cleaned_data.get('cargo_en_comision')

        if cargo and not comision:
            cleaned_data['cargo_en_comision'] = ''

        return cleaned_data

    def clean_dpi(self):
        dpi_raw = self.cleaned_data.get('dpi', '')
        dpi = re.sub(r'\D', '', dpi_raw or '')
        if len(dpi) != 13:
            raise ValidationError('Ingrese un DPI válido de 13 dígitos.')

        duplicado = None
        for afiliado in Afiliado.objects.only('id', 'dpi'):
            if re.sub(r'\D', '', afiliado.dpi or '') == dpi:
                duplicado = afiliado
                break

        if duplicado and (not self.instance or duplicado.pk != self.instance.pk):
            raise ValidationError('Ya existe un afiliado registrado con este DPI.')

        return dpi

    def clean_comunidad(self):
        comunidad = self.cleaned_data.get('comunidad')
        return comunidad or None

    def clean_foto(self):
        foto = self.cleaned_data.get('foto')
        if foto and foto.size > 5 * 1024 * 1024:
            raise ValidationError('La fotografía no puede superar 5 MB.')
        return foto

    def save(self, commit=True):
        afiliado = super().save(commit=commit)

        if commit:
            comision = self.cleaned_data.get('comision')
            cargo = self.cleaned_data.get('cargo_en_comision')

            if comision:
                afiliado.comisiones.set([comision])
                afiliado.cargo_en_comision = cargo or None
            else:
                afiliado.comisiones.clear()
                afiliado.cargo_en_comision = None

            afiliado.save(update_fields=['cargo_en_comision'])

        return afiliado

class ComunidadForm(forms.ModelForm):
    class Meta:
        model = Comunidad
        fields = ['nombre', 'sector']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'sector': forms.Select(attrs={'class': 'form-control'}),
        }



class CentroVotacionForm(forms.ModelForm):
    class Meta:
        model = CentroVotacion
        fields = ['nombre', 'ubicacion', 'sectores']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'ubicacion': forms.TextInput(attrs={'class': 'form-control'}),
            'sectores': forms.SelectMultiple(attrs={
                'class': 'form-control',
                'size': 6,
            }),
        }

# -------------------------------
# Formulario Comisión
# -------------------------------
class ComisionForm(forms.ModelForm):
    class Meta:
        model = Comision
        fields = ['nombre', 'descripcion']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }


class OrganizacionIntegranteForm(forms.ModelForm):
    dpi = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        label='DPI',
    )

    class Meta:
        model = OrganizacionIntegrante
        fields = ['estado', 'observaciones']
        widgets = {
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }


class ComisionForm(forms.ModelForm):
    class Meta:
        model = Comision
        fields = ['nombre', 'descripcion']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }


class SectorForm(forms.ModelForm):
    class Meta:
        model = Sector
        fields = ['nombre', 'descripcion']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }



class OrganizacionTerritorialBaseForm(forms.ModelForm):
    """Formulario base para derivar sector/centro desde comunidad."""

    def _setup_territorio_derivado(self):
        self.fields.pop('sector', None)
        self.fields.pop('centro_votacion', None)

    def _aplicar_territorio_desde_comunidad(self, obj):
        obj.sector = None
        obj.centro_votacion = None
        if obj.comunidad and obj.comunidad.sector:
            obj.sector = obj.comunidad.sector
            obj.centro_votacion = obj.comunidad.sector.centros.first()
        return obj

class CoordinadorOrganizacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = CoordinadorOrganizacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {f: forms.TextInput(attrs={'class': 'form-control'}) for f in ['nombre_completo', 'dpi', 'telefono', 'tipo_coordinacion']}
        widgets.update({
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        })

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class LiderComunitarioOrganizacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = LiderComunitarioOrganizacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador': forms.Select(attrs={'class': 'form-select'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class EstructuraOrganizativaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = EstructuraOrganizativa
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion', 'cantidad_integrantes']
        widgets = {
            'tipo_estructura': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej.: Comité comunitario, Equipo sectorial, Célula territorial'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador_responsable': forms.HiddenInput(),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }
        help_texts = {
            'tipo_estructura': 'Ejemplos: Comité comunitario, Equipo sectorial, Célula territorial, Comisión local, Red de líderes.',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ResponsableTerritorialForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ResponsableTerritorial
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ReunionTerritorialForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ReunionTerritorial
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'fecha': forms.DateInput(
                attrs={'class': 'form-control', 'type': 'date'},
                format='%Y-%m-%d',
            ),
            'tipo_reunion': forms.TextInput(attrs={'class': 'form-control'}),
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsables': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly', 'placeholder': 'Selecciona desde el modal'}),
            'responsable_tipo': forms.HiddenInput(),
            'responsable_referencia_id': forms.HiddenInput(),
            'asistentes': forms.NumberInput(attrs={'class': 'form-control'}),
            'acuerdos': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'estado_seguimiento': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()
        self.fields['fecha'].input_formats = ['%Y-%m-%d']
        if self.instance and self.instance.pk and self.instance.fecha:
            self.initial['fecha'] = self.instance.fecha.strftime('%Y-%m-%d')

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class IncidenciaTerritorialForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = IncidenciaTerritorial
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'tipo_incidencia': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'prioridad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'responsable_asignado': forms.Select(attrs={'class': 'form-select'}),
            'seguimiento': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class JuventudIntegranteForm(forms.ModelForm):
    dpi = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        label='DPI',
    )

    class Meta:
        model = JuventudIntegrante
        fields = ['estado', 'observaciones']
        widgets = {
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }


class CoordinadorJuventudForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = CoordinadorJuventud
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {f: forms.TextInput(attrs={'class': 'form-control'}) for f in ['nombre_completo', 'dpi', 'telefono', 'tipo_coordinacion']}
        widgets.update({
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        })

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class LiderJuvenilForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = LiderJuvenil
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador': forms.Select(attrs={'class': 'form-select'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class EstructuraJuventudForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = EstructuraJuventud
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion', 'cantidad_integrantes']
        widgets = {
            'tipo_estructura': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej.: Comité juvenil, Brigada territorial, Equipo de activismo'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador_responsable': forms.HiddenInput(),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }
        help_texts = {
            'tipo_estructura': 'Ejemplos: Comité juvenil, Brigada barrial, Célula de voluntariado, Red juvenil.',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ResponsableJuventudForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ResponsableJuventud
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ReunionJuventudForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ReunionJuventud
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'),
            'tipo_reunion': forms.TextInput(attrs={'class': 'form-control'}),
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsables': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly', 'placeholder': 'Selecciona desde el modal'}),
            'responsable_tipo': forms.HiddenInput(),
            'responsable_referencia_id': forms.HiddenInput(),
            'asistentes': forms.NumberInput(attrs={'class': 'form-control'}),
            'acuerdos': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'estado_seguimiento': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()
        self.fields['fecha'].input_formats = ['%Y-%m-%d']
        if self.instance and self.instance.pk and self.instance.fecha:
            self.initial['fecha'] = self.instance.fecha.strftime('%Y-%m-%d')

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class IncidenciaJuventudForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = IncidenciaJuventud
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'tipo_incidencia': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'prioridad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'responsable_asignado': forms.Select(attrs={'class': 'form-select'}),
            'seguimiento': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class MujeresIntegranteForm(forms.ModelForm):
    dpi = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        label='DPI',
    )

    class Meta:
        model = MujeresIntegrante
        fields = ['estado', 'observaciones']
        widgets = {
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }


class CoordinadoraMujeresForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = CoordinadoraMujeres
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {f: forms.TextInput(attrs={'class': 'form-control'}) for f in ['nombre_completo', 'dpi', 'telefono', 'tipo_coordinacion']}
        widgets.update({
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        })

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class LiderMujeresForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = LiderMujeres
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador': forms.Select(attrs={'class': 'form-select'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class EstructuraMujeresForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = EstructuraMujeres
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion', 'cantidad_integrantes']
        widgets = {
            'tipo_estructura': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej.: Comité mujeres, Brigada territorial, Equipo de activismo'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador_responsable': forms.HiddenInput(),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }
        help_texts = {
            'tipo_estructura': 'Ejemplos: Comité mujeres, Brigada barrial, Célula de voluntariado, Red mujeres.',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ResponsableMujeresForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ResponsableMujeres
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ReunionMujeresForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ReunionMujeres
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'),
            'tipo_reunion': forms.TextInput(attrs={'class': 'form-control'}),
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsables': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly', 'placeholder': 'Selecciona desde el modal'}),
            'responsable_tipo': forms.HiddenInput(),
            'responsable_referencia_id': forms.HiddenInput(),
            'asistentes': forms.NumberInput(attrs={'class': 'form-control'}),
            'acuerdos': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'estado_seguimiento': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()
        self.fields['fecha'].input_formats = ['%Y-%m-%d']
        if self.instance and self.instance.pk and self.instance.fecha:
            self.initial['fecha'] = self.instance.fecha.strftime('%Y-%m-%d')

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class IncidenciaMujeresForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = IncidenciaMujeres
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'tipo_incidencia': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'prioridad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'responsable_asignado': forms.Select(attrs={'class': 'form-select'}),
            'seguimiento': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class LogisticaIntegranteForm(forms.ModelForm):
    dpi = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        label='DPI',
    )

    class Meta:
        model = LogisticaIntegrante
        fields = ['estado', 'observaciones']
        widgets = {
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }


class CoordinadorLogisticaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = CoordinadorLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {f: forms.TextInput(attrs={'class': 'form-control'}) for f in ['nombre_completo', 'dpi', 'telefono', 'tipo_coordinacion']}
        widgets.update({
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        })

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class LiderLogisticaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = LiderLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador': forms.Select(attrs={'class': 'form-select'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class EstructuraLogisticaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = EstructuraLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion', 'cantidad_integrantes']
        widgets = {
            'tipo_estructura': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej.: Brigada logística, equipo de transporte, comité de suministros'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador_responsable': forms.HiddenInput(),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ResponsableLogisticaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ResponsableLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ReunionLogisticaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ReunionLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'),
            'tipo_reunion': forms.TextInput(attrs={'class': 'form-control'}),
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsables': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly', 'placeholder': 'Selecciona desde el modal'}),
            'responsable_tipo': forms.HiddenInput(),
            'responsable_referencia_id': forms.HiddenInput(),
            'asistentes': forms.NumberInput(attrs={'class': 'form-control'}),
            'acuerdos': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'estado_seguimiento': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()
        self.fields['fecha'].input_formats = ['%Y-%m-%d']
        if self.instance and self.instance.pk and self.instance.fecha:
            self.initial['fecha'] = self.instance.fecha.strftime('%Y-%m-%d')

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class IncidenciaLogisticaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = IncidenciaLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'tipo_incidencia': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'prioridad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'responsable_asignado': forms.Select(attrs={'class': 'form-select'}),
            'seguimiento': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class RecursoLogisticoForm(forms.ModelForm):
    class Meta:
        model = RecursoLogistico
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'tipo_recurso': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }


class AsignacionLogisticaForm(forms.ModelForm):
    class Meta:
        model = AsignacionLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'recurso': forms.Select(attrs={'class': 'form-select'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'actividad': forms.TextInput(attrs={'class': 'form-control'}),
            'responsable': forms.Select(attrs={'class': 'form-select'}),
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }


class SolicitudLogisticaForm(forms.ModelForm):
    class Meta:
        model = SolicitudLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsable': forms.Select(attrs={'class': 'form-select'}),
            'prioridad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }


class EntregaLogisticaForm(forms.ModelForm):
    class Meta:
        model = EntregaLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'solicitud': forms.Select(attrs={'class': 'form-select'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsable': forms.Select(attrs={'class': 'form-select'}),
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'detalle': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
        }


class AgendaLogisticaForm(forms.ModelForm):
    class Meta:
        model = AgendaLogistica
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'actividad': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsables': forms.TextInput(attrs={'class': 'form-control'}),
            'fecha_programada': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }


class ComunicacionIntegranteForm(forms.ModelForm):
    dpi = forms.CharField(max_length=20, required=True, widget=forms.TextInput(attrs={'class': 'form-control'}), label='DPI')

    class Meta:
        model = ComunicacionIntegrante
        fields = ['estado', 'observaciones']
        widgets = {
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }


class CoordinadorComunicacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = CoordinadorComunicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {f: forms.TextInput(attrs={'class': 'form-control'}) for f in ['nombre_completo', 'dpi', 'telefono', 'tipo_coordinacion']}
        widgets.update({'comunidad': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})})

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class LiderComunicacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = LiderComunicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador': forms.Select(attrs={'class': 'form-select'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class EstructuraComunicacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = EstructuraComunicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion', 'cantidad_integrantes']
        widgets = {
            'tipo_estructura': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej.: Equipo digital, célula multimedia, comité territorial de comunicación'}),
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'coordinador_responsable': forms.HiddenInput(),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ResponsableComunicacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ResponsableComunicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}),
            'dpi': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class ReunionComunicacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ReunionComunicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'),
            'tipo_reunion': forms.TextInput(attrs={'class': 'form-control'}),
            'titulo': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'responsables': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly', 'placeholder': 'Selecciona desde el modal'}),
            'responsable_tipo': forms.HiddenInput(),
            'responsable_referencia_id': forms.HiddenInput(),
            'asistentes': forms.NumberInput(attrs={'class': 'form-control'}),
            'acuerdos': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'estado_seguimiento': forms.Select(attrs={'class': 'form-select'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()
        self.fields['fecha'].input_formats = ['%Y-%m-%d']
        if self.instance and self.instance.pk and self.instance.fecha:
            self.initial['fecha'] = self.instance.fecha.strftime('%Y-%m-%d')

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class IncidenciaComunicacionForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = IncidenciaComunicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {
            'tipo_incidencia': forms.TextInput(attrs={'class': 'form-control'}),
            'comunidad': forms.Select(attrs={'class': 'form-select'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'prioridad': forms.Select(attrs={'class': 'form-select'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'responsable_asignado': forms.Select(attrs={'class': 'form-select'}),
            'seguimiento': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._setup_territorio_derivado()

    def save(self, commit=True):
        obj = super().save(commit=False)
        self._aplicar_territorio_desde_comunidad(obj)
        if commit:
            obj.save()
        return obj


class AgendaPublicacionForm(forms.ModelForm):
    class Meta:
        model = AgendaPublicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'plataforma': forms.TextInput(attrs={'class': 'form-control'}), 'tipo_contenido': forms.TextInput(attrs={'class': 'form-control'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'responsable': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class SolicitudContenidoForm(forms.ModelForm):
    class Meta:
        model = SolicitudContenido
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'titulo': forms.TextInput(attrs={'class': 'form-control'}), 'solicitante': forms.TextInput(attrs={'class': 'form-control'}), 'area_solicitante': forms.TextInput(attrs={'class': 'form-control'}), 'prioridad': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class CoberturaActividadForm(forms.ModelForm):
    class Meta:
        model = CoberturaActividad
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'actividad': forms.TextInput(attrs={'class': 'form-control'}), 'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'responsable': forms.Select(attrs={'class': 'form-select'}), 'estado_cobertura': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class BancoMediosForm(forms.ModelForm):
    class Meta:
        model = BancoMedios
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'titulo': forms.TextInput(attrs={'class': 'form-control'}), 'tipo': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'referencia': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class CampanaComunicacionForm(forms.ModelForm):
    class Meta:
        model = CampanaComunicacion
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'nombre': forms.TextInput(attrs={'class': 'form-control'}), 'objetivo': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'fecha_inicio': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'fecha_fin': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'responsable': forms.Select(attrs={'class': 'form-select'})}


class MonitoreoRedForm(forms.ModelForm):
    class Meta:
        model = MonitoreoRed
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'red_social': forms.TextInput(attrs={'class': 'form-control'}), 'actividad': forms.TextInput(attrs={'class': 'form-control'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class PlanHormigaIntegranteForm(forms.ModelForm):
    dpi = forms.CharField(max_length=20, required=True, widget=forms.TextInput(attrs={'class': 'form-control'}), label='DPI')

    class Meta:
        model = PlanHormigaIntegrante
        fields = ['estado', 'observaciones']
        widgets = {'estado': forms.Select(attrs={'class': 'form-control'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 3})}


class CoordinadorPlanHormigaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = CoordinadorPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {f: forms.TextInput(attrs={'class': 'form-control'}) for f in ['nombre_completo', 'dpi', 'telefono', 'tipo_coordinacion']}
        widgets.update({'comunidad': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})})


class EnlaceTerritorialPlanHormigaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = EnlaceTerritorialPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}), 'dpi': forms.TextInput(attrs={'class': 'form-control'}), 'telefono': forms.TextInput(attrs={'class': 'form-control'}), 'coordinador': forms.Select(attrs={'class': 'form-select'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class EstructuraPlanHormigaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = EstructuraPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion', 'cantidad_integrantes']
        widgets = {'tipo_estructura': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej.: Célula territorial, equipo de movilización'}), 'nombre': forms.TextInput(attrs={'class': 'form-control'}), 'coordinador_responsable': forms.HiddenInput(), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class ResponsableZonaPlanHormigaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ResponsableZonaPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'nombre_completo': forms.TextInput(attrs={'class': 'form-control'}), 'dpi': forms.TextInput(attrs={'class': 'form-control'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class ReunionPlanHormigaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = ReunionPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}, format='%Y-%m-%d'), 'tipo_reunion': forms.TextInput(attrs={'class': 'form-control'}), 'titulo': forms.TextInput(attrs={'class': 'form-control'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'responsables': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly', 'placeholder': 'Selecciona desde el modal'}), 'responsable_tipo': forms.HiddenInput(), 'responsable_referencia_id': forms.HiddenInput(), 'asistentes': forms.NumberInput(attrs={'class': 'form-control'}), 'acuerdos': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'estado_seguimiento': forms.Select(attrs={'class': 'form-select'})}


class IncidenciaPlanHormigaForm(OrganizacionTerritorialBaseForm):
    class Meta:
        model = IncidenciaPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'tipo_incidencia': forms.TextInput(attrs={'class': 'form-control'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'prioridad': forms.Select(attrs={'class': 'form-select'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'responsable_asignado': forms.Select(attrs={'class': 'form-select'}), 'seguimiento': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class VisitaPlanHormigaForm(forms.ModelForm):
    class Meta:
        model = VisitaPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'sector': forms.Select(attrs={'class': 'form-select'}), 'responsable': forms.Select(attrs={'class': 'form-select'}), 'tipo_visita': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'estado': forms.Select(attrs={'class': 'form-select'})}


class SeguimientoContactoPlanHormigaForm(forms.ModelForm):
    class Meta:
        model = SeguimientoContactoPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'persona_contactada': forms.TextInput(attrs={'class': 'form-control'}), 'dpi': forms.TextInput(attrs={'class': 'form-control'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'telefono': forms.TextInput(attrs={'class': 'form-control'}), 'estado_seguimiento': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'fecha_ultimo_contacto': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})}


class CompromisoTerritorialPlanHormigaForm(forms.ModelForm):
    class Meta:
        model = CompromisoTerritorialPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'actividad': forms.TextInput(attrs={'class': 'form-control'}), 'responsable': forms.Select(attrs={'class': 'form-select'}), 'comunidad': forms.Select(attrs={'class': 'form-select'}), 'fecha_compromiso': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'estado': forms.Select(attrs={'class': 'form-select'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class PuntoVisitadoPlanHormigaForm(forms.ModelForm):
    class Meta:
        model = PuntoVisitadoPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'comunidad': forms.Select(attrs={'class': 'form-select'}), 'sector': forms.Select(attrs={'class': 'form-select'}), 'responsable': forms.Select(attrs={'class': 'form-select'}), 'cantidad_visitada': forms.NumberInput(attrs={'class': 'form-control'}), 'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class ActivacionTerritorialPlanHormigaForm(forms.ModelForm):
    class Meta:
        model = ActivacionTerritorialPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'comunidad': forms.Select(attrs={'class': 'form-select'}), 'responsable': forms.Select(attrs={'class': 'form-select'}), 'tipo_accion': forms.TextInput(attrs={'class': 'form-control'}), 'fecha': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'resultado': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}


class CoberturaVisitaPlanHormigaForm(forms.ModelForm):
    class Meta:
        model = CoberturaVisitaPlanHormiga
        exclude = ['usuario_creador', 'usuario_modificador', 'fecha_creacion', 'fecha_actualizacion']
        widgets = {'comunidades_atendidas': forms.NumberInput(attrs={'class': 'form-control'}), 'comunidades_pendientes': forms.NumberInput(attrs={'class': 'form-control'}), 'sectores_visitados': forms.NumberInput(attrs={'class': 'form-control'}), 'sectores_pendientes': forms.NumberInput(attrs={'class': 'form-control'}), 'fecha_corte': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}), 'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 2})}
